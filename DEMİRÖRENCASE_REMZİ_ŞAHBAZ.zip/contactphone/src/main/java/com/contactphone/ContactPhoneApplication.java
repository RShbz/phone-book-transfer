package com.contactphone;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ContactPhoneApplication {

	public static void main(String[] args) {
		SpringApplication.run(ContactPhoneApplication.class, args);
		
//		var contact= new Contact();
//		var p1=new Phone();
//		p1.setValue("000");
//		Collection<Phone>  phone= new ArrayList<Phone>();
//		phone.add(p1);
//		contact.setLastName("şah");
//		contact.setName("remzi");
//		
//		
//		
//		contact.setPhone((List<Phone>) phone);
	}

}
