package com.demiroren;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemirorenApplicationTests {

	@Test
	void contextLoads() {
	}

}
